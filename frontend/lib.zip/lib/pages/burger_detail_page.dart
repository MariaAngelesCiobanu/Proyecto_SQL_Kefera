
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class BurgerDetailPage extends StatefulWidget {
  final int idProducto;

  const BurgerDetailPage({
    super.key,
    required this.idProducto,
  });

  @override
  State<BurgerDetailPage> createState() =>
      _BurgerDetailPageState();
}

class _BurgerDetailPageState
    extends State<BurgerDetailPage> {

  final ApiService apiService = ApiService();

  late Future<dynamic> detalleFuture;

  @override
  void initState() {
    super.initState();

    detalleFuture =
        apiService.obtenerDetalleProducto(
      widget.idProducto,
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("Detalle"),
      ),

      body: FutureBuilder<dynamic>(
        future: detalleFuture,

        builder: (context, snapshot) {

          if (snapshot.connectionState ==
              ConnectionState.waiting) {

            return const Center(
              child:
                  CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {

            return Center(
              child: Text(
                snapshot.error.toString(),
              ),
            );
          }

          final producto = snapshot.data;

          return SingleChildScrollView(

            padding:
                const EdgeInsets.all(20),

            child: Column(

              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                ClipRRect(
                  borderRadius:
                      BorderRadius.circular(18),
                  child: Image.asset(
                    "assets/images/logo/logo.png",
                    height: 220,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),

                const SizedBox(height: 20),

                Text(
                  producto["nombre"] ?? "",
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  producto["descripcion"] ?? "",
                  style: const TextStyle(
                    fontSize: 16,
                  ),
                ),

                const SizedBox(height: 25),

                Card(
                  child: Padding(
                    padding:
                        const EdgeInsets.all(16),

                    child: Column(

                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [

                        Text(
                          "Precio: ${producto["precio"]} €",
                        ),

                        const SizedBox(height: 8),

                        Text(
                          "Calorías: ${producto["calorias"]}",
                        ),

                        const SizedBox(height: 8),

                        Text(
                          "Nivel picante: ${producto["nivelPicante"]}",
                        ),

                        const SizedBox(height: 8),

                        Text(
                          "Preparación: ${producto["tiempoPreparacion"]} min",
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                if (producto["historiaEgipcia"] != null)
                  Card(
                    child: Padding(
                      padding:
                          const EdgeInsets.all(16),

                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [

                          const Text(
                            "Historia",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 10),

                          Text(
                            producto["historiaEgipcia"],
                          ),
                        ],
                      ),
                    ),
                  ),

                const SizedBox(height: 30),

                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: () {},
                    child: const Text(
                      "AÑADIR AL CARRITO",
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
