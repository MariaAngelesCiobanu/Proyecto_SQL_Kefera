// categoria_page.dart (plantilla base)

import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/carrito.dart';
import 'burger_detail_page.dart';
import 'carrito_page.dart';

class CategoriaPage extends StatefulWidget {
  final int idCategoria;
  final String nombreCategoria;

  const CategoriaPage({
    super.key,
    required this.idCategoria,
    required this.nombreCategoria,
  });

  @override
  State<CategoriaPage> createState() => _CategoriaPageState();
}

class _CategoriaPageState extends State<CategoriaPage> {
  final ApiService apiService = ApiService();
  late Future<List<dynamic>> productosFuture;

  @override
  void initState() {
    super.initState();
    productosFuture = apiService.obtenerProductosPorCategoria(widget.idCategoria);
  }

  String obtenerImagen(String nombre) {
    return "assets/images/logo/logo.png";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.nombreCategoria),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CarritoPage()),
              );
            },
          )
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: productosFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }

          final productos = snapshot.data ?? [];

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: productos.length,
            itemBuilder: (context, index) {
              final producto = productos[index];

              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        obtenerImagen(producto["nombre"] ?? ""),
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(height: 12),
                      Text(producto["nombre"] ?? ""),
                      Text(producto["descripcion"] ?? ""),
                      Text("${producto["precio"]} €"),
                      ElevatedButton(
                        onPressed: () {
                          Carrito.agregar(producto);
                        },
                        child: const Text("AÑADIR AL CARRITO"),
                      ),
                      if (widget.idCategoria == 3)
                        OutlinedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => BurgerDetailPage(
                                  idProducto: producto["idProducto"],
                                ),
                              ),
                            );
                          },
                          child: const Text("VER DETALLE"),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
