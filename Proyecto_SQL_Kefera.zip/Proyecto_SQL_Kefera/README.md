# Proyecto SQL Kefera

Modelo dimensional de ventas para un restaurante.

## Tablas
- fact_pedidos
- dim_clientes
- dim_productos
- dim_empleados
- dim_fecha

## Tecnologías
PostgreSQL

## Insights
1. Categoría más vendida.
2. Empleado con más ventas.
3. Cliente con mayor gasto.
