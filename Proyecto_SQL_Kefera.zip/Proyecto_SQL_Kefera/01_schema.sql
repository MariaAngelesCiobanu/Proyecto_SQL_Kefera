-- =====================================================
-- PROYECTO SQL - RESTAURANTE KEFERA
-- Modelo dimensional para el análisis de ventas
-- PostgreSQL
-- =====================================================

DROP TABLE IF EXISTS fact_pedidos CASCADE;
DROP TABLE IF EXISTS dim_clientes CASCADE;
DROP TABLE IF EXISTS dim_productos CASCADE;
DROP TABLE IF EXISTS dim_empleados CASCADE;
DROP TABLE IF EXISTS dim_fecha CASCADE;

-- =====================================================
-- TABLAS DE DIMENSIÓN
-- =====================================================

CREATE TABLE dim_clientes (

    cliente_id SERIAL PRIMARY KEY,

    nombre VARCHAR(100) NOT NULL,

    email VARCHAR(120) UNIQUE NOT NULL,

    ciudad VARCHAR(100) DEFAULT 'Madrid',

    fecha_registro DATE NOT NULL

);

CREATE TABLE dim_productos (

    producto_id SERIAL PRIMARY KEY,

    nombre_producto VARCHAR(100) NOT NULL,

    categoria VARCHAR(50) NOT NULL,

    precio NUMERIC(10,2) CHECK(precio > 0),

    activo BOOLEAN DEFAULT TRUE

);

CREATE TABLE dim_empleados (

    empleado_id SERIAL PRIMARY KEY,

    nombre VARCHAR(100) NOT NULL,

    cargo VARCHAR(50) NOT NULL,

    fecha_contratacion DATE NOT NULL

);

CREATE TABLE dim_fecha (

    fecha_id SERIAL PRIMARY KEY,

    fecha DATE NOT NULL UNIQUE,

    dia INT NOT NULL,

    mes INT NOT NULL,

    anio INT NOT NULL,

    trimestre INT NOT NULL

);

-- =====================================================
-- TABLA DE HECHOS
-- =====================================================

CREATE TABLE fact_pedidos (

    pedido_id SERIAL PRIMARY KEY,

    cliente_id INT NOT NULL,

    producto_id INT NOT NULL,

    empleado_id INT NOT NULL,

    fecha_id INT NOT NULL,

    cantidad INT CHECK(cantidad > 0),

    precio_unitario NUMERIC(10,2) CHECK(precio_unitario > 0),

    total NUMERIC(10,2) NOT NULL CHECK(total >= 0),

    CONSTRAINT fk_cliente
        FOREIGN KEY(cliente_id)
        REFERENCES dim_clientes(cliente_id),

    CONSTRAINT fk_producto
        FOREIGN KEY(producto_id)
        REFERENCES dim_productos(producto_id),

    CONSTRAINT fk_empleado
        FOREIGN KEY(empleado_id)
        REFERENCES dim_empleados(empleado_id),

    CONSTRAINT fk_fecha
        FOREIGN KEY(fecha_id)
        REFERENCES dim_fecha(fecha_id)

);

-- =====================================================
-- ÍNDICE
-- =====================================================

CREATE INDEX idx_fact_fecha
ON fact_pedidos(fecha_id);

-- =====================================================
-- VISTAS DE NEGOCIO
-- =====================================================

CREATE VIEW vw_ventas_categoria AS

SELECT
    p.categoria,
    SUM(f.total) AS ventas

FROM fact_pedidos f

INNER JOIN dim_productos p
ON f.producto_id = p.producto_id

GROUP BY p.categoria;

CREATE VIEW vw_rendimiento_empleados AS

SELECT
    e.nombre,
    SUM(f.total) AS total_vendido,
    COUNT(f.pedido_id) AS numero_ventas

FROM fact_pedidos f

INNER JOIN dim_empleados e
ON f.empleado_id = e.empleado_id

GROUP BY e.nombre;

-- =====================================================
-- FUNCTION-- Calcula cuánto dinero se ha gastado un cliente en total.
-- =====================================================

CREATE OR REPLACE FUNCTION obtener_gasto_cliente(
    p_id INT
)
RETURNS NUMERIC
AS $$
DECLARE
    total_gasto NUMERIC;
BEGIN

    SELECT COALESCE(SUM(total),0)
    INTO total_gasto
    FROM fact_pedidos
    WHERE cliente_id = p_id;

    RETURN total_gasto;

END;
$$ LANGUAGE plpgsql;