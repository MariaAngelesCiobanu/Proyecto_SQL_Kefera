-- =====================================================
-- 03_eda.sql
-- EDA Y ANÁLISIS DE NEGOCIO
-- =====================================================

-- =====================================================
-- CALIDAD DE DATOS
-- =====================================================

-- Detectar valores nulos.
SELECT *
FROM dim_clientes
WHERE ciudad IS NULL;

-- Detectar posibles duplicados.
SELECT
email,
COUNT(*)
FROM dim_clientes
GROUP BY email
HAVING COUNT(*) > 1;

-- Detectar posibles valores fuera de rango.
SELECT *
FROM fact_pedidos
WHERE total < 0;

-- Conversión de tipos mediante CAST.
SELECT
pedido_id,
CAST(total AS INTEGER) AS total_entero
FROM fact_pedidos;

-- =====================================================
-- ANÁLISIS DESCRIPTIVO
-- =====================================================

-- Número total de ventas.
SELECT COUNT(*) AS total_ventas
FROM fact_pedidos;

-- Facturación total.
SELECT SUM(total) AS facturacion_total
FROM fact_pedidos;

-- Ticket medio.
SELECT AVG(total) AS ticket_medio
FROM fact_pedidos;

-- Número total de clientes.
SELECT COUNT(*) AS total_clientes
FROM dim_clientes;

-- Número total de productos.
SELECT COUNT(*) AS total_productos
FROM dim_productos;

-- =====================================================
-- JOINS
-- =====================================================

-- INNER JOIN
-- Relación entre clientes y ventas.
SELECT
c.nombre,
f.total
FROM fact_pedidos f
INNER JOIN dim_clientes c
ON f.cliente_id = c.cliente_id;

-- LEFT JOIN
-- Mostrar todos los clientes incluso si no tienen ventas.
SELECT
c.nombre,
f.total
FROM dim_clientes c
LEFT JOIN fact_pedidos f
ON c.cliente_id = f.cliente_id;

-- =====================================================
-- CASE
-- =====================================================

-- Clasificación de productos según precio.

SELECT

nombre_producto,

CASE
WHEN precio < 5 THEN 'Barato'
WHEN precio BETWEEN 5 AND 10 THEN 'Medio'
ELSE 'Premium'
END AS categoria_precio

FROM dim_productos;

-- =====================================================
-- SUBQUERY
-- =====================================================

-- Productos vendidos al menos dos veces.

SELECT *

FROM dim_productos

WHERE producto_id IN (

SELECT producto_id

FROM fact_pedidos

GROUP BY producto_id

HAVING SUM(cantidad) >= 2

);

-- =====================================================
-- CTE
-- =====================================================

WITH ventas_producto AS (

SELECT

producto_id,

SUM(total) AS total_vendido

FROM fact_pedidos

GROUP BY producto_id

)

SELECT *
FROM ventas_producto;

-- =====================================================
-- CTE ENCADENADA + WINDOW FUNCTION
-- =====================================================

WITH ventas AS (

SELECT

producto_id,

SUM(total) AS total_vendido

FROM fact_pedidos

GROUP BY producto_id

),

ranking AS (

SELECT

*,

RANK() OVER(
ORDER BY total_vendido DESC
) AS posicion

FROM ventas

)

SELECT *
FROM ranking;

-- =====================================================
-- FUNCIONES DE FECHA
-- =====================================================

-- Ventas por mes.

SELECT

mes,

COUNT(*) AS total_registros

FROM dim_fecha

GROUP BY mes;

-- =====================================================
-- INSIGHTS DE NEGOCIO
-- =====================================================

-- Insight 1
-- Categoría más rentable.

SELECT *
FROM vw_ventas_categoria;

-- Insight 2
-- Empleados con mejor rendimiento.

SELECT *
FROM vw_rendimiento_empleados;

-- Insight 3
-- Clientes que más gastan.

SELECT

cliente_id,

SUM(total) AS gasto_total

FROM fact_pedidos

GROUP BY cliente_id

ORDER BY gasto_total DESC;

-- Insight 4
-- Productos más vendidos.

SELECT

p.nombre_producto,

SUM(f.cantidad) AS unidades_vendidas

FROM fact_pedidos f

INNER JOIN dim_productos p
ON f.producto_id = p.producto_id

GROUP BY p.nombre_producto

ORDER BY unidades_vendidas DESC;

-- Insight 5
-- Ventas por ciudad.

SELECT

c.ciudad,

SUM(f.total) AS ventas

FROM fact_pedidos f

INNER JOIN dim_clientes c
ON f.cliente_id = c.cliente_id

GROUP BY c.ciudad

ORDER BY ventas DESC;