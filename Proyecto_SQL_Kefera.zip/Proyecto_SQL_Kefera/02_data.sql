-- =====================================================
-- 02_data.sql
-- Carga inicial de datos
-- =====================================================

BEGIN;

-- =====================================================
-- CLIENTES
-- =====================================================

INSERT INTO dim_clientes
(nombre,email,ciudad,fecha_registro)
VALUES

('Ana','[ana@mail.com](mailto:ana@mail.com)','Madrid','2026-01-10'),
('Luis','[luis@mail.com](mailto:luis@mail.com)','Toledo','2026-01-15'),
('Sara','[sara@mail.com](mailto:sara@mail.com)','Sevilla','2026-02-01'),
('Pablo','[pablo@mail.com](mailto:pablo@mail.com)','Madrid','2026-02-10'),
('Elena','[elena@mail.com](mailto:elena@mail.com)','Valencia','2026-03-05'),

('Mario','[mario@mail.com](mailto:mario@mail.com)','Madrid','2026-03-10'),
('Lucia','[lucia@mail.com](mailto:lucia@mail.com)','Barcelona','2026-03-15'),
('David','[david@mail.com](mailto:david@mail.com)','Toledo','2026-04-01'),
('Carmen','[carmen@mail.com](mailto:carmen@mail.com)','Sevilla','2026-04-05'),
('Sergio','[sergio@mail.com](mailto:sergio@mail.com)','Valencia','2026-04-10');

-- =====================================================
-- PRODUCTOS
-- =====================================================

INSERT INTO dim_productos
(nombre_producto,categoria,precio)
VALUES

('Kebab','Comida',12),
('Té Egipcio','Bebida',4),
('Baklava','Postre',5),
('Falafel','Comida',8),
('Refresco','Bebida',3),

('Shawarma','Comida',11),
('Agua','Bebida',2),
('Kunafa','Postre',6),
('Café Árabe','Bebida',3.5),
('Hummus','Entrante',7);

-- =====================================================
-- EMPLEADOS
-- =====================================================

INSERT INTO dim_empleados
(nombre,cargo,fecha_contratacion)
VALUES

('Carlos','Camarero','2025-01-10'),
('Marta','Encargada','2024-06-15'),
('Raul','Camarero','2025-09-01'),
('Sonia','Camarera','2025-11-20'),
('Javier','Camarero','2026-01-10');

-- =====================================================
-- FECHAS
-- =====================================================

INSERT INTO dim_fecha
(fecha,dia,mes,anio,trimestre)
VALUES

('2026-06-01',1,6,2026,2),
('2026-06-02',2,6,2026,2),
('2026-06-03',3,6,2026,2),
('2026-06-04',4,6,2026,2),
('2026-06-05',5,6,2026,2),
('2026-06-06',6,6,2026,2),
('2026-06-07',7,6,2026,2),
('2026-06-08',8,6,2026,2),
('2026-06-09',9,6,2026,2),
('2026-06-10',10,6,2026,2);

-- =====================================================
-- PEDIDOS
-- =====================================================

INSERT INTO fact_pedidos
(cliente_id,producto_id,empleado_id,fecha_id,cantidad,precio_unitario,total)
VALUES

(1,1,1,1,2,12,24),
(2,2,1,2,3,4,12),
(3,3,2,3,1,5,5),
(4,4,3,4,2,8,16),
(5,5,2,5,4,3,12),

(1,2,1,2,2,4,8),
(2,1,3,3,1,12,12),
(3,4,2,4,3,8,24),
(4,5,1,5,2,3,6),
(5,3,2,1,2,5,10),

(6,6,4,6,1,11,11),
(7,7,5,7,2,2,4),
(8,8,3,8,1,6,6),
(9,9,4,9,3,3.5,10.5),
(10,10,5,10,2,7,14),

(1,6,1,6,2,11,22),
(2,8,2,7,1,6,6),
(3,10,3,8,2,7,14),
(4,1,4,9,1,12,12),
(5,2,5,10,3,4,12);

-- =====================================================
-- UPDATE
-- =====================================================

UPDATE dim_clientes
SET ciudad = 'Barcelona'
WHERE cliente_id = 1;

-- =====================================================
-- DELETE
-- =====================================================

DELETE FROM fact_pedidos
WHERE pedido_id = 999;

COMMIT;  /*este commit existe pq hay antes un begin y es una transaccion*/
